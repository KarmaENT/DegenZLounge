# DeGeNz Lounge - Multi-Model AI Integration

This archive contains the complete implementation of the DeGeNz Lounge webapp with multi-model AI integration. The application supports multiple AI platforms including Gemini (default), DeepSeek, Grok, Hugging Face, OpenRouter, Anthropic, Mistral AI, Perplexity, and Ollama.

## Features

- **Multiple AI Provider Support**: Seamlessly switch between different AI providers
- **Free Tier Optimization**: Maximize usage of free API tiers
- **Model Selection**: Choose from a wide range of models for each provider
- **Usage Tracking**: Monitor token usage across different providers
- **Response Caching**: Reduce API calls with intelligent caching
- **Self-hosted Models**: Support for Ollama local models

## Directory Structure

```
degenz-lounge/
├── backend/               # Flask backend with WebSocket support
│   ├── app/               # Application code
│   │   ├── api/           # API routes
│   │   ├── models/        # Database models
│   │   └── services/      # Business logic and AI providers
│   ├── tests/             # Backend tests
│   └── Dockerfile         # Backend Docker configuration
├── frontend/              # React frontend
│   └── degenz-frontend/   # React application
│       ├── src/           # Source code
│       │   ├── components/# React components
│       │   ├── contexts/  # React contexts
│       │   └── pages/     # Page components
│       ├── tests/         # Frontend tests
│       └── Dockerfile     # Frontend Docker configuration
├── database/              # Database migrations and scripts
├── docs/                  # Documentation
├── docker-compose.yml     # Docker Compose configuration
└── deploy.sh              # Deployment script
```

## Deployment Instructions

### Prerequisites

- Docker and Docker Compose
- Git
- Bash shell

### Quick Start

1. Clone the repository:
   ```
   git clone <repository-url>
   cd degenz-lounge
   ```

2. Run the deployment script:
   ```
   ./deploy.sh
   ```

3. Access the application:
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:5000
   - Ollama API: http://localhost:11434

### Manual Deployment

1. Create a `.env` file with the following variables:
   ```
   POSTGRES_USER=degenz
   POSTGRES_PASSWORD=degenzpassword
   POSTGRES_DB=degenzdb
   SECRET_KEY=your-secret-key
   FLASK_ENV=production
   REACT_APP_API_URL=http://localhost:5000
   
   # AI Provider API Keys
   GEMINI_API_KEY=
   DEEPSEEK_API_KEY=
   HUGGINGFACE_API_KEY=
   OPENROUTER_API_KEY=
   ANTHROPIC_API_KEY=
   MISTRAL_API_KEY=
   PERPLEXITY_API_KEY=
   GROK_API_KEY=
   OLLAMA_URL=http://ollama:11434
   ```

2. Build and start the containers:
   ```
   docker-compose up -d --build
   ```

3. Initialize the database:
   ```
   docker-compose exec backend flask db init
   docker-compose exec backend flask db migrate -m "Initial migration"
   docker-compose exec backend flask db upgrade
   ```

4. Pull Ollama models (optional):
   ```
   docker-compose exec ollama ollama pull llama2
   docker-compose exec ollama ollama pull mistral
   ```

## AI Provider Configuration

### Adding API Keys

You can add API keys in two ways:

1. Through the UI: Go to Settings > AI Model Settings > API Keys
2. In the `.env` file: Add your API keys before deployment

### Free Tier Usage

The following providers offer free tiers:

- **Gemini**: Unlimited for basic usage
- **DeepSeek**: 10,000 tokens monthly
- **Hugging Face**: Unlimited for open models
- **OpenRouter**: $5 free credits for new users
- **Mistral AI**: $5 free credits
- **Perplexity**: 5,000 tokens per day
- **Ollama**: Unlimited (self-hosted)

## Development

### Backend Development

1. Create a virtual environment:
   ```
   cd backend
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

2. Run the development server:
   ```
   flask run --debug
   ```

### Frontend Development

1. Install dependencies:
   ```
   cd frontend/degenz-frontend
   npm install
   ```

2. Run the development server:
   ```
   npm start
   ```

### Running Tests

Backend tests:
```
cd backend
python -m unittest discover tests
```

Frontend tests:
```
cd frontend/degenz-frontend
npm test
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.
