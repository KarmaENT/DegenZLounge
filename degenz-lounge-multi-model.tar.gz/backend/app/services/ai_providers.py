import os
import json
import requests
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any, Union

class AIModelProvider(ABC):
    """Abstract base class for AI model providers."""
    
    @abstractmethod
    def generate_text(self, prompt: str, system_message: str = None, 
                     temperature: float = 0.7, max_tokens: int = 1000, 
                     stream: bool = False, **kwargs) -> str:
        """Generate text from the model."""
        pass
    
    @abstractmethod
    def get_available_models(self) -> List[Dict[str, Any]]:
        """Get list of available models from this provider."""
        pass
    
    @abstractmethod
    def get_token_usage(self, prompt: str, response: str) -> Dict[str, int]:
        """Get token usage for a prompt and response."""
        pass
    
    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Get the name of the provider."""
        pass
    
    @property
    @abstractmethod
    def has_free_tier(self) -> bool:
        """Check if the provider has a free tier."""
        pass
    
    @property
    @abstractmethod
    def supports_streaming(self) -> bool:
        """Check if the provider supports streaming responses."""
        pass

class GeminiProvider(AIModelProvider):
    """Provider for Google's Gemini models."""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY")
        if not self.api_key:
            raise ValueError("Gemini API key is required")
        
        self.base_url = "https://generativelanguage.googleapis.com/v1beta"
        self.models = {
            "gemini-flash-2.0": "models/gemini-flash-2.0:generateContent",
            "gemini-pro": "models/gemini-pro:generateContent",
            "gemini-ultra": "models/gemini-ultra:generateContent"
        }
        self.default_model = "gemini-flash-2.0"
    
    def generate_text(self, prompt: str, system_message: str = None, 
                     temperature: float = 0.7, max_tokens: int = 1000, 
                     stream: bool = False, model: str = None, **kwargs) -> str:
        """Generate text using Gemini models."""
        model_endpoint = self.models.get(model or self.default_model)
        
        url = f"{self.base_url}/{model_endpoint}?key={self.api_key}"
        
        payload = {
            "contents": [
                {
                    "role": "user",
                    "parts": [{"text": prompt}]
                }
            ],
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_tokens,
                "topP": kwargs.get("top_p", 0.95),
                "topK": kwargs.get("top_k", 40)
            }
        }
        
        if system_message:
            payload["systemInstruction"] = {"parts": [{"text": system_message}]}
        
        headers = {
            "Content-Type": "application/json"
        }
        
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        
        result = response.json()
        
        if "candidates" in result and len(result["candidates"]) > 0:
            return result["candidates"][0]["content"]["parts"][0]["text"]
        
        return ""
    
    def get_available_models(self) -> List[Dict[str, Any]]:
        """Get list of available Gemini models."""
        return [
            {
                "id": "gemini-flash-2.0",
                "name": "Gemini Flash 2.0",
                "description": "Fast and efficient model for general tasks",
                "context_length": 32000,
                "pricing": "Free tier available"
            },
            {
                "id": "gemini-pro",
                "name": "Gemini Pro",
                "description": "Balanced model for complex reasoning",
                "context_length": 32000,
                "pricing": "Pay per token"
            },
            {
                "id": "gemini-ultra",
                "name": "Gemini Ultra",
                "description": "Most capable model for complex tasks",
                "context_length": 32000,
                "pricing": "Pay per token"
            }
        ]
    
    def get_token_usage(self, prompt: str, response: str) -> Dict[str, int]:
        """Estimate token usage for Gemini models."""
        # Simple estimation: ~4 characters per token
        prompt_tokens = len(prompt) // 4
        completion_tokens = len(response) // 4
        
        return {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens
        }
    
    @property
    def provider_name(self) -> str:
        return "Gemini"
    
    @property
    def has_free_tier(self) -> bool:
        return True
    
    @property
    def supports_streaming(self) -> bool:
        return True

class DeepSeekProvider(AIModelProvider):
    """Provider for DeepSeek AI models."""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.environ.get("DEEPSEEK_API_KEY")
        if not self.api_key:
            raise ValueError("DeepSeek API key is required")
        
        self.base_url = "https://api.deepseek.ai/v1"
        self.models = {
            "deepseek-chat": "chat/completions",
            "deepseek-coder": "code/completions"
        }
        self.default_model = "deepseek-chat"
    
    def generate_text(self, prompt: str, system_message: str = None, 
                     temperature: float = 0.7, max_tokens: int = 1000, 
                     stream: bool = False, model: str = None, **kwargs) -> str:
        """Generate text using DeepSeek models."""
        endpoint = self.models.get(model or self.default_model)
        url = f"{self.base_url}/{endpoint}"
        
        messages = []
        if system_message:
            messages.append({"role": "system", "content": system_message})
        
        messages.append({"role": "user", "content": prompt})
        
        payload = {
            "model": model or self.default_model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream
        }
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        
        result = response.json()
        
        if "choices" in result and len(result["choices"]) > 0:
            return result["choices"][0]["message"]["content"]
        
        return ""
    
    def get_available_models(self) -> List[Dict[str, Any]]:
        """Get list of available DeepSeek models."""
        return [
            {
                "id": "deepseek-chat",
                "name": "DeepSeek Chat",
                "description": "General purpose chat model",
                "context_length": 8192,
                "pricing": "Limited free tier available"
            },
            {
                "id": "deepseek-coder",
                "name": "DeepSeek Coder",
                "description": "Specialized for code generation and understanding",
                "context_length": 8192,
                "pricing": "Limited free tier available"
            }
        ]
    
    def get_token_usage(self, prompt: str, response: str) -> Dict[str, int]:
        """Estimate token usage for DeepSeek models."""
        # Simple estimation: ~4 characters per token
        prompt_tokens = len(prompt) // 4
        completion_tokens = len(response) // 4
        
        return {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens
        }
    
    @property
    def provider_name(self) -> str:
        return "DeepSeek"
    
    @property
    def has_free_tier(self) -> bool:
        return True
    
    @property
    def supports_streaming(self) -> bool:
        return True

class HuggingFaceProvider(AIModelProvider):
    """Provider for Hugging Face models."""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.environ.get("HUGGINGFACE_API_KEY")
        if not self.api_key:
            raise ValueError("Hugging Face API key is required")
        
        self.base_url = "https://api-inference.huggingface.co/models"
        self.default_model = "mistralai/Mistral-7B-Instruct-v0.2"
    
    def generate_text(self, prompt: str, system_message: str = None, 
                     temperature: float = 0.7, max_tokens: int = 1000, 
                     stream: bool = False, model: str = None, **kwargs) -> str:
        """Generate text using Hugging Face models."""
        model_name = model or self.default_model
        url = f"{self.base_url}/{model_name}"
        
        # Format prompt based on model
        formatted_prompt = prompt
        if system_message:
            if "mistral" in model_name.lower():
                formatted_prompt = f"<s>[INST] {system_message}\n\n{prompt} [/INST]"
            elif "llama" in model_name.lower():
                formatted_prompt = f"<s>[INST] <<SYS>>\n{system_message}\n<</SYS>>\n\n{prompt} [/INST]"
            else:
                formatted_prompt = f"{system_message}\n\n{prompt}"
        
        payload = {
            "inputs": formatted_prompt,
            "parameters": {
                "temperature": temperature,
                "max_new_tokens": max_tokens,
                "return_full_text": False
            }
        }
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        
        result = response.json()
        
        if isinstance(result, list) and len(result) > 0:
            return result[0].get("generated_text", "")
        
        return ""
    
    def get_available_models(self) -> List[Dict[str, Any]]:
        """Get list of available Hugging Face models."""
        return [
            {
                "id": "mistralai/Mistral-7B-Instruct-v0.2",
                "name": "Mistral 7B Instruct",
                "description": "Efficient instruction-following model",
                "context_length": 8192,
                "pricing": "Free with API key"
            },
            {
                "id": "meta-llama/Llama-2-7b-chat-hf",
                "name": "Llama 2 7B Chat",
                "description": "Meta's conversational model",
                "context_length": 4096,
                "pricing": "Free with API key"
            },
            {
                "id": "tiiuae/falcon-7b-instruct",
                "name": "Falcon 7B Instruct",
                "description": "Instruction-tuned model from TII",
                "context_length": 2048,
                "pricing": "Free with API key"
            }
        ]
    
    def get_token_usage(self, prompt: str, response: str) -> Dict[str, int]:
        """Estimate token usage for Hugging Face models."""
        # Simple estimation: ~4 characters per token
        prompt_tokens = len(prompt) // 4
        completion_tokens = len(response) // 4
        
        return {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens
        }
    
    @property
    def provider_name(self) -> str:
        return "Hugging Face"
    
    @property
    def has_free_tier(self) -> bool:
        return True
    
    @property
    def supports_streaming(self) -> bool:
        return False

class OpenRouterProvider(AIModelProvider):
    """Provider for OpenRouter models."""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.environ.get("OPENROUTER_API_KEY")
        if not self.api_key:
            raise ValueError("OpenRouter API key is required")
        
        self.base_url = "https://openrouter.ai/api/v1"
        self.default_model = "openai/gpt-3.5-turbo"
    
    def generate_text(self, prompt: str, system_message: str = None, 
                     temperature: float = 0.7, max_tokens: int = 1000, 
                     stream: bool = False, model: str = None, **kwargs) -> str:
        """Generate text using OpenRouter models."""
        url = f"{self.base_url}/chat/completions"
        
        messages = []
        if system_message:
            messages.append({"role": "system", "content": system_message})
        
        messages.append({"role": "user", "content": prompt})
        
        payload = {
            "model": model or self.default_model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream
        }
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
            "HTTP-Referer": "https://degenz-lounge.com",  # Required by OpenRouter
            "X-Title": "DeGeNz Lounge"  # Required by OpenRouter
        }
        
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        
        result = response.json()
        
        if "choices" in result and len(result["choices"]) > 0:
            return result["choices"][0]["message"]["content"]
        
        return ""
    
    def get_available_models(self) -> List[Dict[str, Any]]:
        """Get list of available OpenRouter models."""
        # This would typically fetch from OpenRouter's API
        # For now, we'll return a static list of popular models
        return [
            {
                "id": "openai/gpt-3.5-turbo",
                "name": "GPT-3.5 Turbo",
                "description": "Fast and efficient model from OpenAI",
                "context_length": 16385,
                "pricing": "Pay per token, with free credits for new users"
            },
            {
                "id": "anthropic/claude-3-haiku",
                "name": "Claude 3 Haiku",
                "description": "Fast and efficient model from Anthropic",
                "context_length": 200000,
                "pricing": "Pay per token, with free credits for new users"
            },
            {
                "id": "mistralai/mistral-7b-instruct",
                "name": "Mistral 7B Instruct",
                "description": "Efficient open-source model",
                "context_length": 8192,
                "pricing": "Pay per token, with free credits for new users"
            }
        ]
    
    def get_token_usage(self, prompt: str, response: str) -> Dict[str, int]:
        """Get token usage from OpenRouter response."""
        # In a real implementation, this would parse the usage from the API response
        # For now, we'll use a simple estimation
        prompt_tokens = len(prompt) // 4
        completion_tokens = len(response) // 4
        
        return {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens
        }
    
    @property
    def provider_name(self) -> str:
        return "OpenRouter"
    
    @property
    def has_free_tier(self) -> bool:
        return True
    
    @property
    def supports_streaming(self) -> bool:
        return True

class AnthropicProvider(AIModelProvider):
    """Provider for Anthropic Claude models."""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise ValueError("Anthropic API key is required")
        
        self.base_url = "https://api.anthropic.com/v1"
        self.default_model = "claude-3-haiku-20240307"
    
    def generate_text(self, prompt: str, system_message: str = None, 
                     temperature: float = 0.7, max_tokens: int = 1000, 
                     stream: bool = False, model: str = None, **kwargs) -> str:
        """Generate text using Anthropic Claude models."""
        url = f"{self.base_url}/messages"
        
        payload = {
            "model": model or self.default_model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": temperature
        }
        
        if system_message:
            payload["system"] = system_message
        
        headers = {
            "Content-Type": "application/json",
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01"
        }
        
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        
        result = response.json()
        
        if "content" in result and len(result["content"]) > 0:
            return result["content"][0]["text"]
        
        return ""
    
    def get_available_models(self) -> List[Dict[str, Any]]:
        """Get list of available Anthropic models."""
        return [
            {
                "id": "claude-3-opus-20240229",
                "name": "Claude 3 Opus",
                "description": "Most powerful Claude model for complex tasks",
                "context_length": 200000,
                "pricing": "Pay per token"
            },
            {
                "id": "claude-3-sonnet-20240229",
                "name": "Claude 3 Sonnet",
                "description": "Balanced performance and cost",
                "context_length": 200000,
                "pricing": "Pay per token"
            },
            {
                "id": "claude-3-haiku-20240307",
                "name": "Claude 3 Haiku",
                "description": "Fast and efficient model",
                "context_length": 200000,
                "pricing": "Pay per token"
            }
        ]
    
    def get_token_usage(self, prompt: str, response: str) -> Dict[str, int]:
        """Estimate token usage for Anthropic models."""
        # Simple estimation: ~4 characters per token
        prompt_tokens = len(prompt) // 4
        completion_tokens = len(response) // 4
        
        return {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens
        }
    
    @property
    def provider_name(self) -> str:
        return "Anthropic"
    
    @property
    def has_free_tier(self) -> bool:
        return False
    
    @property
    def supports_streaming(self) -> bool:
        return True

class MistralAIProvider(AIModelProvider):
    """Provider for Mistral AI models."""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.environ.get("MISTRAL_API_KEY")
        if not self.api_key:
            raise ValueError("Mistral API key is required")
        
        self.base_url = "https://api.mistral.ai/v1"
        self.default_model = "mistral-small-latest"
    
    def generate_text(self, prompt: str, system_message: str = None, 
                     temperature: float = 0.7, max_tokens: int = 1000, 
                     stream: bool = False, model: str = None, **kwargs) -> str:
        """Generate text using Mistral AI models."""
        url = f"{self.base_url}/chat/completions"
        
        messages = []
        if system_message:
            messages.append({"role": "system", "content": system_message})
        
        messages.append({"role": "user", "content": prompt})
        
        payload = {
            "model": model or self.default_model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream
        }
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        
        result = response.json()
        
        if "choices" in result and len(result["choices"]) > 0:
            return result["choices"][0]["message"]["content"]
        
        return ""
    
    def get_available_models(self) -> List[Dict[str, Any]]:
        """Get list of available Mistral AI models."""
        return [
            {
                "id": "mistral-tiny-latest",
                "name": "Mistral Tiny",
                "description": "Fast and cost-effective model",
                "context_length": 32000,
                "pricing": "Pay per token, with free tier"
            },
            {
                "id": "mistral-small-latest",
                "name": "Mistral Small",
                "description": "Balanced performance and cost",
                "context_length": 32000,
                "pricing": "Pay per token, with free tier"
            },
            {
                "id": "mistral-medium-latest",
                "name": "Mistral Medium",
                "description": "Advanced reasoning capabilities",
                "context_length": 32000,
                "pricing": "Pay per token"
            },
            {
                "id": "mistral-large-latest",
                "name": "Mistral Large",
                "description": "Most powerful Mistral model",
                "context_length": 32000,
                "pricing": "Pay per token"
            }
        ]
    
    def get_token_usage(self, prompt: str, response: str) -> Dict[str, int]:
        """Estimate token usage for Mistral AI models."""
        # Simple estimation: ~4 characters per token
        prompt_tokens = len(prompt) // 4
        completion_tokens = len(response) // 4
        
        return {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens
        }
    
    @property
    def provider_name(self) -> str:
        return "Mistral AI"
    
    @property
    def has_free_tier(self) -> bool:
        return True
    
    @property
    def supports_streaming(self) -> bool:
        return True

class PerplexityProvider(AIModelProvider):
    """Provider for Perplexity models."""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.environ.get("PERPLEXITY_API_KEY")
        if not self.api_key:
            raise ValueError("Perplexity API key is required")
        
        self.base_url = "https://api.perplexity.ai"
        self.default_model = "pplx-7b-online"
    
    def generate_text(self, prompt: str, system_message: str = None, 
                     temperature: float = 0.7, max_tokens: int = 1000, 
                     stream: bool = False, model: str = None, **kwargs) -> str:
        """Generate text using Perplexity models."""
        url = f"{self.base_url}/chat/completions"
        
        messages = []
        if system_message:
            messages.append({"role": "system", "content": system_message})
        
        messages.append({"role": "user", "content": prompt})
        
        payload = {
            "model": model or self.default_model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream
        }
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        
        result = response.json()
        
        if "choices" in result and len(result["choices"]) > 0:
            return result["choices"][0]["message"]["content"]
        
        return ""
    
    def get_available_models(self) -> List[Dict[str, Any]]:
        """Get list of available Perplexity models."""
        return [
            {
                "id": "pplx-7b-online",
                "name": "Perplexity 7B Online",
                "description": "7B parameter model with online search capabilities",
                "context_length": 4096,
                "pricing": "Pay per token, with free tier"
            },
            {
                "id": "pplx-70b-online",
                "name": "Perplexity 70B Online",
                "description": "70B parameter model with online search capabilities",
                "context_length": 4096,
                "pricing": "Pay per token"
            },
            {
                "id": "pplx-7b-chat",
                "name": "Perplexity 7B Chat",
                "description": "7B parameter model optimized for chat",
                "context_length": 4096,
                "pricing": "Pay per token, with free tier"
            },
            {
                "id": "pplx-70b-chat",
                "name": "Perplexity 70B Chat",
                "description": "70B parameter model optimized for chat",
                "context_length": 4096,
                "pricing": "Pay per token"
            }
        ]
    
    def get_token_usage(self, prompt: str, response: str) -> Dict[str, int]:
        """Estimate token usage for Perplexity models."""
        # Simple estimation: ~4 characters per token
        prompt_tokens = len(prompt) // 4
        completion_tokens = len(response) // 4
        
        return {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens
        }
    
    @property
    def provider_name(self) -> str:
        return "Perplexity"
    
    @property
    def has_free_tier(self) -> bool:
        return True
    
    @property
    def supports_streaming(self) -> bool:
        return True

class GrokProvider(AIModelProvider):
    """Provider for xAI's Grok models."""
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.environ.get("GROK_API_KEY")
        if not self.api_key:
            raise ValueError("Grok API key is required")
        
        self.base_url = "https://api.grok.x.ai/v1"
        self.default_model = "grok-1"
    
    def generate_text(self, prompt: str, system_message: str = None, 
                     temperature: float = 0.7, max_tokens: int = 1000, 
                     stream: bool = False, model: str = None, **kwargs) -> str:
        """Generate text using Grok models."""
        url = f"{self.base_url}/chat/completions"
        
        messages = []
        if system_message:
            messages.append({"role": "system", "content": system_message})
        
        messages.append({"role": "user", "content": prompt})
        
        payload = {
            "model": model or self.default_model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream
        }
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        
        result = response.json()
        
        if "choices" in result and len(result["choices"]) > 0:
            return result["choices"][0]["message"]["content"]
        
        return ""
    
    def get_available_models(self) -> List[Dict[str, Any]]:
        """Get list of available Grok models."""
        return [
            {
                "id": "grok-1",
                "name": "Grok-1",
                "description": "xAI's conversational AI with real-time knowledge",
                "context_length": 8192,
                "pricing": "Limited access through platform"
            }
        ]
    
    def get_token_usage(self, prompt: str, response: str) -> Dict[str, int]:
        """Estimate token usage for Grok models."""
        # Simple estimation: ~4 characters per token
        prompt_tokens = len(prompt) // 4
        completion_tokens = len(response) // 4
        
        return {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens
        }
    
    @property
    def provider_name(self) -> str:
        return "Grok"
    
    @property
    def has_free_tier(self) -> bool:
        return False
    
    @property
    def supports_streaming(self) -> bool:
        return True

class OllamaProvider(AIModelProvider):
    """Provider for Ollama self-hosted models."""
    
    def __init__(self, base_url: str = "http://localhost:11434"):
        self.base_url = base_url
        self.default_model = "llama2"
    
    def generate_text(self, prompt: str, system_message: str = None, 
                     temperature: float = 0.7, max_tokens: int = 1000, 
                     stream: bool = False, model: str = None, **kwargs) -> str:
        """Generate text using Ollama models."""
        url = f"{self.base_url}/api/generate"
        
        # Format prompt based on model
        formatted_prompt = prompt
        if system_message:
            formatted_prompt = f"{system_message}\n\n{prompt}"
        
        payload = {
            "model": model or self.default_model,
            "prompt": formatted_prompt,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream
        }
        
        headers = {
            "Content-Type": "application/json"
        }
        
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        
        result = response.json()
        
        return result.get("response", "")
    
    def get_available_models(self) -> List[Dict[str, Any]]:
        """Get list of available Ollama models."""
        try:
            response = requests.get(f"{self.base_url}/api/tags")
            if response.status_code == 200:
                models = response.json().get("models", [])
                return [
                    {
                        "id": model["name"],
                        "name": model["name"].capitalize(),
                        "description": "Self-hosted model via Ollama",
                        "context_length": model.get("context_length", 2048),
                        "pricing": "Free (self-hosted)"
                    }
                    for model in models
                ]
        except:
            pass
        
        # Fallback to common models
        return [
            {
                "id": "llama2",
                "name": "Llama 2",
                "description": "Meta's general purpose model",
                "context_length": 4096,
                "pricing": "Free (self-hosted)"
            },
            {
                "id": "mistral",
                "name": "Mistral",
                "description": "Efficient open-source model",
                "context_length": 8192,
                "pricing": "Free (self-hosted)"
            },
            {
                "id": "codellama",
                "name": "CodeLlama",
                "description": "Specialized for code generation",
                "context_length": 4096,
                "pricing": "Free (self-hosted)"
            }
        ]
    
    def get_token_usage(self, prompt: str, response: str) -> Dict[str, int]:
        """Estimate token usage for Ollama models."""
        # Simple estimation: ~4 characters per token
        prompt_tokens = len(prompt) // 4
        completion_tokens = len(response) // 4
        
        return {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens
        }
    
    @property
    def provider_name(self) -> str:
        return "Ollama"
    
    @property
    def has_free_tier(self) -> bool:
        return True
    
    @property
    def supports_streaming(self) -> bool:
        return True

class AIModelManager:
    """Manager class for handling multiple AI model providers."""
    
    def __init__(self):
        self.providers = {}
        self.default_provider = None
        self.usage_stats = {
            "total_tokens": 0,
            "providers": {}
        }
    
    def register_provider(self, provider: AIModelProvider, is_default: bool = False):
        """Register a new provider."""
        self.providers[provider.provider_name] = provider
        
        if is_default or self.default_provider is None:
            self.default_provider = provider.provider_name
        
        # Initialize usage stats for this provider
        self.usage_stats["providers"][provider.provider_name] = {
            "total_tokens": 0,
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "requests": 0
        }
    
    def get_provider(self, provider_name: str = None) -> AIModelProvider:
        """Get a provider by name, or the default provider if none specified."""
        if provider_name is None:
            provider_name = self.default_provider
        
        if provider_name not in self.providers:
            raise ValueError(f"Provider '{provider_name}' not registered")
        
        return self.providers[provider_name]
    
    def set_default_provider(self, provider_name: str):
        """Set the default provider."""
        if provider_name not in self.providers:
            raise ValueError(f"Provider '{provider_name}' not registered")
        
        self.default_provider = provider_name
    
    def get_all_providers(self) -> Dict[str, AIModelProvider]:
        """Get all registered providers."""
        return self.providers
    
    def get_all_models(self) -> Dict[str, List[Dict[str, Any]]]:
        """Get all available models from all providers."""
        models = {}
        for provider_name, provider in self.providers.items():
            models[provider_name] = provider.get_available_models()
        
        return models
    
    def get_free_tier_providers(self) -> Dict[str, AIModelProvider]:
        """Get all providers with free tiers."""
        return {
            name: provider 
            for name, provider in self.providers.items() 
            if provider.has_free_tier
        }
    
    def generate_text(self, prompt: str, system_message: str = None, 
                     temperature: float = 0.7, max_tokens: int = 1000, 
                     stream: bool = False, provider_name: str = None, 
                     model: str = None, **kwargs) -> str:
        """Generate text using the specified provider and model."""
        provider = self.get_provider(provider_name)
        
        response = provider.generate_text(
            prompt=prompt,
            system_message=system_message,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=stream,
            model=model,
            **kwargs
        )
        
        # Update usage statistics
        usage = provider.get_token_usage(prompt, response)
        self._update_usage_stats(provider.provider_name, usage)
        
        return response
    
    def _update_usage_stats(self, provider_name: str, usage: Dict[str, int]):
        """Update usage statistics."""
        provider_stats = self.usage_stats["providers"][provider_name]
        
        provider_stats["total_tokens"] += usage["total_tokens"]
        provider_stats["prompt_tokens"] += usage["prompt_tokens"]
        provider_stats["completion_tokens"] += usage["completion_tokens"]
        provider_stats["requests"] += 1
        
        self.usage_stats["total_tokens"] += usage["total_tokens"]
    
    def get_usage_stats(self) -> Dict[str, Any]:
        """Get current usage statistics."""
        return self.usage_stats
    
    def reset_usage_stats(self):
        """Reset usage statistics."""
        for provider_name in self.usage_stats["providers"]:
            self.usage_stats["providers"][provider_name] = {
                "total_tokens": 0,
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "requests": 0
            }
        
        self.usage_stats["total_tokens"] = 0
    
    def find_best_free_provider(self) -> Optional[str]:
        """Find the best available free provider based on usage and availability."""
        free_providers = self.get_free_tier_providers()
        
        if not free_providers:
            return None
        
        # Sort by usage (least used first)
        sorted_providers = sorted(
            free_providers.keys(),
            key=lambda p: self.usage_stats["providers"][p]["total_tokens"]
        )
        
        return sorted_providers[0] if sorted_providers else None

# Example usage
if __name__ == "__main__":
    # Initialize manager
    manager = AIModelManager()
    
    # Register providers (with mock API keys for example)
    try:
        manager.register_provider(GeminiProvider("MOCK_API_KEY"), is_default=True)
        manager.register_provider(DeepSeekProvider("MOCK_API_KEY"))
        manager.register_provider(HuggingFaceProvider("MOCK_API_KEY"))
        manager.register_provider(OpenRouterProvider("MOCK_API_KEY"))
        manager.register_provider(AnthropicProvider("MOCK_API_KEY"))
        manager.register_provider(MistralAIProvider("MOCK_API_KEY"))
        manager.register_provider(PerplexityProvider("MOCK_API_KEY"))
        manager.register_provider(GrokProvider("MOCK_API_KEY"))
        
        # Only register Ollama if it's available
        try:
            ollama = OllamaProvider()
            # Test connection
            ollama.get_available_models()
            manager.register_provider(ollama)
        except:
            print("Ollama not available, skipping")
        
        # Print available models
        models = manager.get_all_models()
        for provider, provider_models in models.items():
            print(f"\n{provider} Models:")
            for model in provider_models:
                print(f"  - {model['name']}: {model['description']}")
        
        # Print free tier providers
        free_providers = manager.get_free_tier_providers()
        print("\nFree Tier Providers:")
        for provider in free_providers:
            print(f"  - {provider}")
        
    except ValueError as e:
        print(f"Error: {e}")
        print("This is expected in the example as we're using mock API keys.")
