from flask import Blueprint

bp = Blueprint('api', __name__, url_prefix='/api')

# Import and register routes
from app.api.agent_routes import register_agent_routes
from app.api.sandbox_routes import register_sandbox_routes
from app.api.auth_routes import register_auth_routes

# Register routes with blueprints
register_agent_routes(bp)
register_sandbox_routes(bp)
register_auth_routes(bp)
