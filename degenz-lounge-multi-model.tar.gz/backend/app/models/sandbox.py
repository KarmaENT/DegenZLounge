from sqlalchemy import Column, Integer, String, Text, JSON, ForeignKey, DateTime, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import datetime

from app.models.agent import Base

class Sandbox(Base):
    __tablename__ = 'sandboxes'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    mode = Column(String(50), default='collaborative')  # collaborative or strict
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
    user_id = Column(Integer, ForeignKey('users.id'))
    
    # Relationships
    user = relationship("User", back_populates="sandboxes")
    agents = relationship("AgentSession", back_populates="sandbox", cascade="all, delete-orphan")
    messages = relationship("Message", back_populates="sandbox", cascade="all, delete-orphan")
    
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "mode": self.mode,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "user_id": self.user_id
        }


class AgentSession(Base):
    __tablename__ = 'agent_sessions'
    
    id = Column(Integer, primary_key=True)
    sandbox_id = Column(Integer, ForeignKey('sandboxes.id'), nullable=False)
    agent_id = Column(Integer, ForeignKey('agents.id'), nullable=False)
    is_manager = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Relationships
    sandbox = relationship("Sandbox", back_populates="agents")
    agent = relationship("Agent", back_populates="sessions")
    
    def to_dict(self):
        return {
            "id": self.id,
            "sandbox_id": self.sandbox_id,
            "agent_id": self.agent_id,
            "is_manager": self.is_manager,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }


class Message(Base):
    __tablename__ = 'messages'
    
    id = Column(Integer, primary_key=True)
    sandbox_id = Column(Integer, ForeignKey('sandboxes.id'), nullable=False)
    sender_type = Column(String(20), nullable=False)  # 'user', 'agent', 'manager'
    sender_id = Column(Integer)  # user_id or agent_id
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Relationships
    sandbox = relationship("Sandbox", back_populates="messages")
    
    def to_dict(self):
        return {
            "id": self.id,
            "sandbox_id": self.sandbox_id,
            "sender_type": self.sender_type,
            "sender_id": self.sender_id,
            "content": self.content,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }
